<template>
    <div>
        <TaskTwo/>
    </div>
</template>
<script setup >
import TaskTwo from "./components/TaskTwo.vue";

</script>