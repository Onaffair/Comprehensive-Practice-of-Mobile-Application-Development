import {defineStore} from "pinia";


const useUserStore = defineStore('userStore',{
    state: () =>({
        name:"22211860247-周智",
        age:21,
        gender:"男"
    }),
    getters:{
        getName:(state) => state.name,
        getAge:(state) => state.age,
        getGender:(state) => state.gender,
    },
    actions:{
        setName(name){
            this.name = name
        },
        setAge(age){
            this.age = age
        },
        setGender(gender){
            this.gender = gender
        }
    },
    persist:{
        enabled:true,
        strategies:[
            {
                storage:localStorage,
                key:'userStore',
            }
        ]
    }
})
export default useUserStore