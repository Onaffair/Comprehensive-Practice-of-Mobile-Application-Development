<template>
    <div>
        <ChildModule/>

    </div>
</template>
<script setup >
import ChildModule from "./components/ChildModule.vue";





</script>