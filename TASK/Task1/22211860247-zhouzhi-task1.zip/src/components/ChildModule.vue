<script setup>
import useUserStore from "../store/UserStore.js";

const userStore = useUserStore();


const changeGender =() =>{
    if (userStore.getGender === '男'){
        userStore.setGender('女')
    }else if (userStore.getGender === '女'){
        userStore.setGender('男')
    }
}

</script>

<template>
    <div>
        <h1>我是ChildModule组件</h1>
        <p>姓名:{{userStore.getName}}</p>
        <p>年龄:{{userStore.getAge}}</p>
        <p>性别:{{userStore.getGender}}</p>
        <button @click="changeGender">修改性别</button>
        <button @click="userStore.setGender('保密')">保密性别</button>
        <button @click="userStore.setGender('男')">重置数据</button>
        <p>
            {{userStore.getGender==='男'
                ?'Male'
                :userStore.getGender==='女'?'Female'
                :'Unknown'}}
        </p>
    </div>
</template>

<style scoped>

</style>