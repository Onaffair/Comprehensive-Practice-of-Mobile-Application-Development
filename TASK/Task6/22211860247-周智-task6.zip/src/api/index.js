import {_axios} from "../util/index.js";
import qs  from 'qs'
import {alertFail, showSuccess} from "../util/showMessages.js";


const login = (loginData) =>{
    return _axios({
        url:"auth/jwt/login",
        method:"post",
        data:qs.stringify(loginData)
    })
        .then(res =>{
            _axios.defaults.headers["authorization"] = "Bearer " + res.data.access_token;
            return res.data
        })
        .catch(error => error)
}

const profile = () =>{
    return _axios({
        url:"users/mine/",
        method:"get"
    })
        .then(res => res?.data)
        .catch(error => {
            alertFail(profile.name,error)
        })
}

const logout = () =>{
    return _axios({
        url:"auth/jwt/logout",
        method:"post"
    })
        .then(res =>{
            _axios.defaults.headers["authorization"]=''
            return res.data
        }).catch(error => error)
}

const userRename = async (postData) =>{
   try{
       let data = await _axios.post('/users/rename/',postData)
       showSuccess(userRename.name,data)
       return Promise.resolve(data)
   }catch (e){
       alertFail(userRename.name,e)
   }
}
const userModifyPwd = async (pwd) =>{

    try{
        let user = await profile()
        if (user){
            user.password = pwd

            let res = await _axios.patch('/users/me',user)

            if (res.data){
                showSuccess(userModifyPwd.name,res?.data)
                return Promise.resolve(res.data)
            }else{
                alertFail(userModifyPwd.name,res?.data)
            }
        }else{
            alertFail(userModifyPwd.name,'获取用户信息失败')
        }
    }catch (e){
        alertFail(userModifyPwd.name,e)
    }
}




export {
    login,
    profile,
    logout,
    userRename,
    userModifyPwd
}
