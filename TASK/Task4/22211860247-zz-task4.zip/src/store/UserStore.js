import {defineStore} from "pinia";


const useUserStore = defineStore('userStore',{
    state: () =>({
        isLogin:false,
        token:"",
        user:{}
    }),
    getters:{
        getUser:(state) => state.user,
        getToken:(state) => state.token,
        getIsLogin:(state) => state.isLogin,
    },
    actions:{
        setUser(user){
            this.user = user
        },
        setToken(token){
            this.token = token
        },
        setLoginState(isLogin){
            this.isLogin = isLogin
        }
    },
    persist: true
})
export default useUserStore