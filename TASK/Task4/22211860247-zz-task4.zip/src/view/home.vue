<template>
    <div>
        <div style="display: flex;justify-content: center;">
            <NutButton type='info' @click="router.push({name:'login'})">去登录页面</NutButton>
        </div>
    </div>
</template>
<script setup>
import { useRouter } from 'vue-router';


const router = useRouter()

</script>