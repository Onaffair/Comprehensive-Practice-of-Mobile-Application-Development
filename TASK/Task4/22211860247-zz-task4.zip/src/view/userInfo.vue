<template>

    <div>
        <div v-if="userInfo">
            <p>
                {{ userInfo }}
            </p>
            <div style="display: flex;justify-content: center;">
                <NutButton type='primary' @click="userQuit">登出</NutButton>
            </div>
        </div>
    </div>
</template>
<script setup>
import { onBeforeMount,ref } from 'vue';
import { logout, profile } from '../api';
import { useRouter } from 'vue-router';

const userInfo = ref(null)
const router = useRouter()


const userQuit = () =>{
    logout()
        .then(res =>{
            router.push({name:'login'})
        })
}

onBeforeMount(() =>{
    profile()
        .then(res => {
            userInfo.value = res
        })
})



</script>