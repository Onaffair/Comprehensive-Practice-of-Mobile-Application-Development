<template>
    <div>
        <div>
            <NutCell title='22211860247-周智' size="large"/>
        </div>
        <div style="display: flex;justify-content: center;">
            <img src='../img/forsaken.jpg' style="width: 100%;"/>
        </div>
        <div>
            <NutForm >
                <NutFormItem label="用户名">
                    <NutInput v-model='loginData.username'/>
                </NutFormItem>
                <NutFormItem label="密码">
                    <NutInput type="password" v-model='loginData.password'/>
                </NutFormItem>
            </NutForm>
            <div style="display: flex;justify-content: center;">
                <NutButton type='info' @click="postLoginData">登录</NutButton>
            </div>
        </div>
    
    </div>
</template>
<script setup>
import { reactive } from 'vue';
import { login } from '../api';
import { showToast } from '@nutui/nutui';

const loginData = reactive({
    username: '',
    password: ''
})

const postLoginData = () =>{
    
    login(loginData)
        .then(res =>{
            showToast.success(JSON.stringify(res))
        })

}


</script>