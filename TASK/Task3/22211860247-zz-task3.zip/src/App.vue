<template>
    <div>
        <router-view/>
    </div>
</template>
<script setup >


</script>