<template>
    <nut-navbar title="22211860247-周智" left-show @click-back="router.back()"></nut-navbar>

    <div>
        <router-view/>
    </div>
</template>
<script setup >
import { Left } from '@nutui/icons-vue';
import { useRouter } from 'vue-router';
const router = useRouter()
</script>