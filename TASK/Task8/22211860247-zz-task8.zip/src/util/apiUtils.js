import {_axios} from "./index.js";
import {showFail, showSuccess} from "./showMessages.js";

const apiDeleteImageByPath = async (path) =>{
    console.log(apiDeleteImageByPath.name,path)

    if (path){
        try{
            let data  = await  _axios({
                method:'delete',
                url:'/deleteimage-bypath' + path
            })
            showSuccess(apiDeleteImageByPath.name,data)
            return Promise.resolve(data)
        }catch (e) {
            showFail(apiDeleteImageByPath.name,e)
        }
    }else{
        showFail(apiDeleteImageByPath.name,'待删除path不能为空')
    }

}

export {
    apiDeleteImageByPath
}