import {createRouter,createWebHashHistory} from "vue-router";

const routes = [
    {
        path: '/',
        redirect: '/home'
    },
    {
        path: '/home',
        name:'home',
        component : () => import('../view/home.vue'),
    },
    {
        path: '/login',
        name:'login',
        component : () => import('../view/login.vue'),
    },
    {
        path:'/userInfo',
        name: 'userInfo',
        component: () => import('../view/UserInfo.vue')
    },
    {
        path: '/register',
        name: 'register',
        component: () => import('../view/register.vue')
    },
    {
        path: '/settings',
        name:'settings',
        component : () => import('../view/MySettings.vue'),
    }
]
const router = createRouter({
    history: createWebHashHistory(),
    routes
})
export default router