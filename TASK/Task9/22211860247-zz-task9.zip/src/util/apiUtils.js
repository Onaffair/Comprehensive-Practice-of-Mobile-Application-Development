import {_axios} from "./index.js";
import {showFail, showSuccess} from "./showMessages.js";
import {ref, toValue, watchEffect} from "vue";

const apiDeleteImageByPath = async (path) =>{
    console.log(apiDeleteImageByPath.name,path)

    if (path){
        try{
            let data  = await  _axios({
                method:'delete',
                url:'/deleteimage-bypath' + path
            })
            showSuccess(apiDeleteImageByPath.name,data)
            return Promise.resolve(data)
        }catch (e) {
            showFail(apiDeleteImageByPath.name,e)
        }
    }else{
        showFail(apiDeleteImageByPath.name,'待删除path不能为空')
    }

}

const apiGetAllItemsRefresh = (timeCounter, query = ref('skip=0&limit=100')) =>{

    let list = ref(null),
        error = ref(null),
        isLoading = ref(true),
        url

    watchEffect(() =>{
        url = '/items/auto-refresh/'+ toValue(timeCounter) + '?' + toValue(query)
        isLoading.value = true
        _axios.get(url)
            .then(res =>{
                if (res?.data){
                    list.value = res.data
                }
                isLoading.value = false
                error.value = null
            }).catch(e =>{
                error.value = e?.message ? e.message : JSON.stringify(e,null,1)
                isLoading.value = false
            })

    })
    return {
        list,
        error,
        isLoading,
    }
}


export {
    apiDeleteImageByPath,
    apiGetAllItemsRefresh,
}