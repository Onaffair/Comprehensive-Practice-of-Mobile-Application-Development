<template>

    <div>
        <router-view/>
    </div>
</template>
<script setup >
import {onBeforeMount, onBeforeUnmount} from "vue";
import useCounterStore from "./store/useCounterStore.js";

const counterStore = useCounterStore()


onBeforeMount(() =>{
    counterStore.startTImer()
})
onBeforeUnmount(() =>{
    counterStore.stopTimer()
})

</script>