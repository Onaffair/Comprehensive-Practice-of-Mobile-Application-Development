


const imageBaseUrl = 'http://localhost'
const baseUrl = imageBaseUrl + '/'
const imgUpLoadUrl = imageBaseUrl + '/uploadimage/'
const defaultImageSrc = '/images/word.png'

export {
    imageBaseUrl,
    baseUrl,
    imgUpLoadUrl,
    defaultImageSrc
}