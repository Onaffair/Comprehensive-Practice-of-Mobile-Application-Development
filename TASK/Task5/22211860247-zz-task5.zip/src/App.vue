<template>
    <div>
        <div>
            <NutCell >
                <template #title>
                    <div style="display: inline-flex;">
                        <Left @click="router.go(-1)"/>
                        <div style="margin-left: 40%;">
                            22211860247-周智
                        </div>
                    </div>
                </template>
            </NutCell>
        </div>
        <router-view/>
    </div>
</template>
<script setup >
import { Left } from '@nutui/icons-vue';
import { useRouter } from 'vue-router';
const router = useRouter()
</script>