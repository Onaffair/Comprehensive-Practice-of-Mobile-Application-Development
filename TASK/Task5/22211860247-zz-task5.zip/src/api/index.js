import {_axios} from "../util/index.js";
import qs  from 'qs'


const login = (loginData) =>{
    return _axios({
        url:"auth/jwt/login",
        method:"post",
        data:qs.stringify(loginData)
    })
        .then(res =>{
            _axios.defaults.headers["authorization"] = "Bearer " + res.data.access_token;
            return res.data
        })
        .catch(error => error)
}

const profile = () =>{
    return _axios({
        url:"users/me",
        method:"get"
    })
        .then(res => res.data)
        .catch(error => error)
}

const logout = () =>{
    return _axios({
        url:"auth/jwt/logout",
        method:"post"
    })
        .then(res =>{
            _axios.defaults.headers["authorization"]=''
            return res.data
        }).catch(error => error)
}




export {
    login,
    profile,
    logout
}
