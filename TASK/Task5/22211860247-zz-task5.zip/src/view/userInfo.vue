<template>
    <div>
        <div v-if="userInfo">
            <p>
                {{ userInfo }}
            </p>
            <div style="display: flex;justify-content: center;">
                <NutButton type='primary' @click="userQuit">登出</NutButton>
            </div>
            <div>
                
            </div>
        </div>
    </div>
</template>
<script setup>
import { onBeforeMount,ref } from 'vue';
import { logout, profile } from '../api';
import { useRouter } from 'vue-router';
import useUserStore from "../store/UserStore.js";

const userInfo = ref(null)
const router = useRouter()
const userStore = useUserStore()

const userQuit = () =>{
    logout()
        .then(res =>{
            userStore.setUser(res)
            userStore.setToken("")
            userStore.setLoginState(false)
            router.push({name:'login'})
        })
}

onBeforeMount(() =>{
    profile()
        .then(res => {
            userStore.setUser(res)
            userInfo.value = res
        })
})



</script>